const gemini = () => { 
	return `       
Gemini (21 Mei – 20 Juni)

Gemini (♊)[1] adalah zodiak ketiga yang berasal dari konstelasi Gemini. Di bawah zodiak tropis, matahari transit tanda ini antara 21 Mei dan 21 Juni. Gemini diwakili oleh si Kembar Castor dan Pollux.[2] simbol kembar ini didasarkan pada Dioscuri, dua manusia yang diberikan bersama kekuatan dewa setelah kematian mereka.
`
}
exports.gemini = gemini